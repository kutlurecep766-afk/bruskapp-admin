export default function QrMenuPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-white">QR Menu Yonetimi</h1><p className="text-sm text-gray-500 mt-1">Aktif: 156 QR menu</p></div>
        <button className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-blue-500/20 transition-all">+ Yeni QR Menu</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {[
          { label: 'Toplam QR Menu', value: '234', change: '+12', color: 'blue' },
          { label: 'Aylik Goruntulenme', value: '45.2K', change: '%23', color: 'emerald' },
          { label: 'QR Tiklanma', value: '12.8K', change: '%18', color: 'violet' },
        ].map((s,i)=>(
          <div key={i} className="bg-[#0d1117]/80 backdrop-blur-xl border border-[#1a2332] rounded-2xl p-5">
            <p className="text-xs text-gray-500 uppercase tracking-wider">{s.label}</p>
            <p className="text-2xl font-bold text-white mt-1">{s.value}</p>
            <p className={'text-xs mt-1'+(s.color==='blue'?' text-blue-400':s.color==='emerald'?' text-emerald-400':' text-violet-400')}>{s.change} bu ay</p>
          </div>
        ))}
      </div>
      <div className="bg-[#0d1117]/80 backdrop-blur-xl border border-[#1a2332] rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-[#1a2332]">{['Isletme','QR Kod','Goruntulenme','Tiklanma','Durum','Olusturma'].map(h=><th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-[#1a2332]">
              {[{name:'ABC Restoran',views:'12.4K',clicks:'3.2K',status:'Aktif'},{name:'ZL Kafe',views:'8.7K',clicks:'2.1K',status:'Aktif'},{name:'MD Catering',views:'3.2K',clicks:'856',status:'Pasif'}].map((m,i)=>(
                <tr key={i} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-4 py-3 text-white font-medium">{m.name}</td>
                  <td className="px-4 py-3"><span className="font-mono text-blue-400 text-xs">****{1234+i*1234}</span></td>
                  <td className="px-4 py-3 text-gray-300">{m.views}</td>
                  <td className="px-4 py-3 text-gray-300">{m.clicks}</td>
                  <td className="px-4 py-3"><span className={'px-2.5 py-0.5 rounded-full text-xs font-medium border '+(m.status==='Aktif'?'bg-emerald-500/10 text-emerald-400 border-emerald-500/20':'bg-red-500/10 text-red-400 border-red-500/20')}>{m.status}</span></td>
                  <td className="px-4 py-3 text-gray-400">2025</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}