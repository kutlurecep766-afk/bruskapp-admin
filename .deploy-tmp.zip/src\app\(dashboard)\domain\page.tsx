'use client'
import { useState, useEffect } from 'react'
import { Globe, ExternalLink, Check, Palette, Type, Image, Save, Copy, CheckCircle, AlertCircle, RefreshCw, XCircle, Loader2 } from 'lucide-react'

type SslStatus = 'pending' | 'checking' | 'active' | 'failed'

export default function DomainPage() {
  const [tab, setTab] = useState<'domain' | 'brand'>('domain')
  const [loading, setLoading] = useState(true)
  const [tenantId, setTenantId] = useState<string | null>(null)

  const [domain, setDomain] = useState('')
  const [savedDomain, setSavedDomain] = useState('')
  const [sslStatus, setSslStatus] = useState<SslStatus>('pending')
  const [domainSaved, setDomainSaved] = useState(false)
  const [copied, setCopied] = useState(false)

  const [brand, setBrand] = useState({
    siteTitle: '',
    primaryColor: '#6366f1',
    secondaryColor: '#1e1b4b',
    logoUrl: '',
  })
  const [brandSaved, setBrandSaved] = useState(false)

  const lsKey = 'bruskapp_domain_ssl'

  async function api(url: string, options?: RequestInit) {
    let res = await fetch(url, { credentials: 'include', ...options })
    if (res.status === 401) {
      const refresh = await fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
      if (refresh.ok) res = await fetch(url, { credentials: 'include', ...options })
    }
    return res
  }

  useEffect(() => {
    async function load() {
      try {
        const lsSsl = localStorage.getItem(lsKey)
        const savedSsl = lsSsl ? JSON.parse(lsSsl) : null

        const userRes = await api('/api/users/me')
        if (userRes.ok) {
          const user = await userRes.json()
          setTenantId(user.tenantId)

          const tRes = await api(`/api/tenants/${user.tenantId}`)
          if (tRes.ok) {
            const tenant = await tRes.json()
            if (tenant.domain) {
              setDomain(tenant.domain)
              setSavedDomain(tenant.domain)
              if (savedSsl?.domain === tenant.domain) {
                setSslStatus(savedSsl.status)
              }
            }
            setBrand({
              siteTitle: tenant.siteTitle || '',
              primaryColor: tenant.primaryColor || '#6366f1',
              secondaryColor: tenant.secondaryColor || '#1e1b4b',
              logoUrl: tenant.logoUrl || '',
            })
          }
        }
      } catch {}
      setLoading(false)
    }
    load()
  }, [])

  const checkSsl = (d: string) => {
    setSslStatus('checking')
    localStorage.setItem(lsKey, JSON.stringify({ domain: d, status: 'checking' }))
    let attempts = 0
    const maxAttempts = 30
    const check = async () => {
      attempts++
      try {
        await fetch(`https://${d}`, { method: 'HEAD', mode: 'no-cors' })
        setSslStatus('active')
        localStorage.setItem(lsKey, JSON.stringify({ domain: d, status: 'active' }))
      } catch {
        if (attempts >= maxAttempts) {
          setSslStatus('failed')
          localStorage.setItem(lsKey, JSON.stringify({ domain: d, status: 'failed' }))
          return
        }
        await new Promise(r => setTimeout(r, 5000))
        check()
      }
    }
    check()
  }

  const handleSaveDomain = async () => {
    if (!tenantId || !domain) return
    const res = await api(`/api/tenants/${tenantId}/domain`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain }),
    })
    if (res.ok) {
      setSavedDomain(domain)
      setSslStatus('pending')
      setDomainSaved(true)
      setTimeout(() => setDomainSaved(false), 3000)
      checkSsl(domain)
    }
  }

  const handleRetry = () => {
    if (savedDomain) checkSsl(savedDomain)
  }

  const handleCopy = (text: string) => {
    navigator.clipboard?.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSaveBrand = async () => {
    if (!tenantId) return
    const res = await api(`/api/tenants/${tenantId}/theme`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        siteTitle: brand.siteTitle,
        primaryColor: brand.primaryColor,
        logoUrl: brand.logoUrl,
      }),
    })
    if (res.ok) {
      setBrandSaved(true)
      setTimeout(() => setBrandSaved(false), 3000)
    }
  }

  const domainStatusInfo = () => {
    switch (sslStatus) {
      case 'pending':
        return { label: 'SSL Bekleniyor', cls: 'bg-amber-500/10 text-amber-400 border-amber-500/20', icon: Loader2 }
      case 'checking':
        return { label: 'SSL Kontrol Ediliyor...', cls: 'bg-blue-500/10 text-blue-400 border-blue-500/20', icon: RefreshCw }
      case 'active':
        return { label: 'SSL Aktif - Yayında', cls: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', icon: CheckCircle }
      case 'failed':
        return { label: 'SSL Başarısız - Tekrar Dene', cls: 'bg-red-500/10 text-red-400 border-red-500/20', icon: XCircle }
    }
  }

  const st = domainStatusInfo()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 size={24} className="text-gray-500 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Domain & Marka</h1>
        <p className="text-gray-500 text-sm mt-1">Kendi domaininizi bağlayın ve markanızı özelleştirin</p>
      </div>

      <div className="flex gap-1 bg-[#0d1117]/80 border border-[#1a2332] rounded-xl p-1">
        <button onClick={() => setTab('domain')} className={'flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ' + (tab === 'domain' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'text-gray-500 hover:text-gray-300')}><Globe size={16} /> Domain Bağlama</button>
        <button onClick={() => setTab('brand')} className={'flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ' + (tab === 'brand' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'text-gray-500 hover:text-gray-300')}><Palette size={16} /> Marka Özelleştirme</button>
      </div>

      {tab === 'domain' && (
        <div className="space-y-6">
          {savedDomain && (
            <div className="glass rounded-2xl border border-[#1a2332] p-6">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <h2 className="text-white font-semibold text-base">Aktif Domain</h2>
                  <p className="text-xs text-gray-500 mt-1">Aşağıdaki domain paneline bağlı:</p>
                  <div className="flex items-center gap-2 mt-3">
                    <Globe size={18} className="text-emerald-400" />
                    <span className="text-lg font-semibold text-white">{savedDomain}</span>
                    <span className={'inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium border ' + st.cls}>
                      <st.icon size={12} className={sslStatus === 'checking' ? 'animate-spin' : ''} />{st.label}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {sslStatus === 'failed' && <button onClick={handleRetry} className="flex items-center gap-1 px-3 py-2 bg-red-500/10 text-red-400 rounded-xl text-xs font-medium border border-red-500/20 hover:bg-red-500/20 transition-all"><RefreshCw size={13} /> Tekrar Dene</button>}
                  <a href={`https://${savedDomain}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-3 py-2 bg-emerald-500/10 text-emerald-400 rounded-xl text-xs font-medium border border-emerald-500/20 hover:bg-emerald-500/20 transition-all"><ExternalLink size={13} /> Siteyi Aç</a>
                </div>
              </div>
            </div>
          )}

          <div className="glass rounded-2xl border border-[#1a2332] p-6 space-y-5">
            <div>
              <h2 className="text-white font-semibold text-base">Özel Domain Bağla</h2>
              <p className="text-xs text-gray-500 mt-1">Kendi domain adresinizi BruskApp paneline yönlendirin. Müşterileriniz markanıza özel URL ile erişsin.</p>
            </div>

            <div>
              <label className="text-xs text-gray-500 block mb-1.5">Domain Adresiniz</label>
              <div className="flex gap-2">
                <input type="text" value={domain} onChange={e => setDomain(e.target.value)} placeholder="ornek.com" className="flex-1 bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" />
                <button onClick={handleSaveDomain} disabled={!domain} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50"><Save size={15} /> Kaydet</button>
              </div>
              {domainSaved && <p className="text-xs text-emerald-400 mt-2 flex items-center gap-1"><CheckCircle size={12} /> Domain kaydedildi. DNS yayılması ve SSL kontrolü başlatıldı.</p>}
            </div>
          </div>

          <div className="glass rounded-2xl border border-[#1a2332] p-6 space-y-4">
            <h2 className="text-white font-semibold text-base">DNS Yapılandırması</h2>
            <p className="text-xs text-gray-500">Domain sağlayıcınızda (Cloudflare, Godaddy, Namecheap, IHS, vb.) aşağıdaki DNS kayıtlarını ekleyin:</p>

            <div className="space-y-3">
              <div className="bg-[#080b12] rounded-xl p-4 border border-[#1a2332]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-white">A Kaydı (Root)</span>
                  {copied ? <Check size={14} className="text-emerald-400" /> : <button onClick={() => handleCopy('@')} className="text-xs text-gray-500 hover:text-white flex items-center gap-1"><Copy size={12} /> Kopyala</button>}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-gray-500">Tür:</span> <span className="text-white">A</span></div>
                  <div><span className="text-gray-500">Ad:</span> <span className="text-white">@</span></div>
                  <div><span className="text-gray-500">Değer:</span> <span className="text-emerald-400 font-mono">147.93.72.130</span></div>
                  <div><span className="text-gray-500">TTL:</span> <span className="text-white">Auto / 600</span></div>
                </div>
              </div>
              <div className="bg-[#080b12] rounded-xl p-4 border border-[#1a2332]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-white">A Kaydı (n8n)</span>
                  <button onClick={() => handleCopy('n8n')} className="text-xs text-gray-500 hover:text-white flex items-center gap-1"><Copy size={12} /> Kopyala</button>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-gray-500">Tür:</span> <span className="text-white">A</span></div>
                  <div><span className="text-gray-500">Ad:</span> <span className="text-white">n8n</span></div>
                  <div><span className="text-gray-500">Değer:</span> <span className="text-emerald-400 font-mono">147.93.72.130</span></div>
                  <div><span className="text-gray-500">TTL:</span> <span className="text-white">Auto / 600</span></div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl">
              <AlertCircle size={16} className="text-amber-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-medium text-amber-400">DNS değişiklikleri 24-48 saat içinde tüm dünyada yayılır.</p>
                <p className="text-xs text-gray-500 mt-1">Kaydettikten sonra SSL durumu otomatik kontrol edilir ve yayına alınır.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'brand' && (
        <div className="space-y-6">
          <div className="glass rounded-2xl border border-[#1a2332] p-6 space-y-5">
            <div>
              <h2 className="text-white font-semibold text-base">Marka Ayarları</h2>
              <p className="text-xs text-gray-500 mt-1">Müşteri panelinizin ve sitenizin görünümünü özelleştirin.</p>
            </div>

            <div>
              <label className="text-xs text-gray-500 block mb-1.5"><Type size={12} className="inline mr-1" />Site Başlığı</label>
              <input type="text" value={brand.siteTitle} onChange={e => setBrand({ ...brand, siteTitle: e.target.value })} placeholder="İşletme Adı" className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-gray-500 block mb-1.5"><Palette size={12} className="inline mr-1" />Ana Renk</label>
                <div className="flex gap-2">
                  <div className="relative"><input type="color" value={brand.primaryColor} onChange={e => setBrand({ ...brand, primaryColor: e.target.value })} className="w-10 h-10 rounded-lg border border-[#1a2332] cursor-pointer bg-transparent [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded-lg [&::-webkit-color-swatch]:border-none" /></div>
                  <input type="text" value={brand.primaryColor} onChange={e => setBrand({ ...brand, primaryColor: e.target.value })} className="flex-1 bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 transition-all font-mono" />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-500 block mb-1.5">İkincil Renk</label>
                <div className="flex gap-2">
                  <div className="relative"><input type="color" value={brand.secondaryColor} onChange={e => setBrand({ ...brand, secondaryColor: e.target.value })} className="w-10 h-10 rounded-lg border border-[#1a2332] cursor-pointer bg-transparent [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded-lg [&::-webkit-color-swatch]:border-none" /></div>
                  <input type="text" value={brand.secondaryColor} onChange={e => setBrand({ ...brand, secondaryColor: e.target.value })} className="flex-1 bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 transition-all font-mono" />
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs text-gray-500 block mb-1.5"><Image size={12} className="inline mr-1" />Logo URL</label>
              <input type="text" value={brand.logoUrl} onChange={e => setBrand({ ...brand, logoUrl: e.target.value })} placeholder="https://ornek.com/logo.png" className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" />
              {brand.logoUrl && <div className="mt-2 flex items-center gap-3 p-3 bg-[#080b12] rounded-xl border border-[#1a2332]"><img src={brand.logoUrl} alt="logo preview" className="w-10 h-10 rounded-lg object-cover bg-white/5" onError={(e) => (e.target as HTMLImageElement).style.display = 'none'} /><span className="text-xs text-gray-500">Önizleme</span></div>}
            </div>

            <div className="flex items-start gap-3 p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: brand.primaryColor + '20' }}><Palette size={14} style={{ color: brand.primaryColor }} /></div>
              <div>
                <p className="text-xs font-medium text-white">Canlı Önizleme</p>
                <div className="flex gap-2 mt-2">
                  <span className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: brand.primaryColor }} />
                  <span className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: brand.secondaryColor }} />
                  <span className="text-sm font-semibold text-white leading-6">{brand.siteTitle}</span>
                </div>
              </div>
            </div>

            <button onClick={handleSaveBrand} className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all"><Save size={15} /> Marka Ayarlarını Kaydet</button>
            {brandSaved && <p className="text-xs text-emerald-400 text-center flex items-center justify-center gap-1"><CheckCircle size={12} /> Marka ayarları kaydedildi</p>}
          </div>
        </div>
      )}
    </div>
  )
}
