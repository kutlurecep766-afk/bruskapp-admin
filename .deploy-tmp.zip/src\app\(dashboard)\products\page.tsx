'use client'
import { useState } from 'react'
import { Package, Plus, Pencil, Trash2, X, Search, Image as ImageIcon, Tag, Layers, DollarSign } from 'lucide-react'

const CATEGORIES = [
  'Yiyecek', 'İçecek', 'Tatlı', 'Kahvaltı', 'Ara Sıcak', 'Salata', 'Fast Food'
]

const MOCK_PRODUCTS = [
  { id: '1', name: 'Karışık Pizza', category: 'Yiyecek', price: 189.90, stock: 50, image: null, active: true },
  { id: '2', name: 'Kola 330ml', category: 'İçecek', price: 24.90, stock: 200, image: null, active: true },
  { id: '3', name: 'Baklava', category: 'Tatlı', price: 89.90, stock: 30, image: null, active: true },
  { id: '4', name: 'Serpme Kahvaltı', category: 'Kahvaltı', price: 149.90, stock: 20, image: null, active: true },
  { id: '5', name: 'Patates Kızartması', category: 'Ara Sıcak', price: 44.90, stock: 100, image: null, active: false },
]

export default function ProductsPage() {
  const [products, setProducts] = useState<any[]>(MOCK_PRODUCTS)
  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ name: '', category: 'Yiyecek', price: '', stock: '', active: true, image: null as string | null })

  const openCreate = () => {
    setEditing(null)
    setForm({ name: '', category: 'Yiyecek', price: '', stock: '', active: true, image: null })
    setShowModal(true)
  }

  const openEdit = (p: any) => {
    setEditing(p)
    setForm({ name: p.name, category: p.category, price: String(p.price), stock: String(p.stock), active: p.active, image: p.image })
    setShowModal(true)
  }

  const save = () => {
    if (!form.name || !form.price) return
    if (editing) {
      setProducts(prev => prev.map(p => p.id === editing.id ? { ...p, ...form, price: Number(form.price), stock: Number(form.stock) } : p))
    } else {
      setProducts(prev => [...prev, { id: String(Date.now()), ...form, price: Number(form.price), stock: Number(form.stock) }])
    }
    setShowModal(false)
  }

  const remove = (id: string) => {
    if (!confirm('Ürünü silmek istediğinize emin misiniz?')) return
    setProducts(prev => prev.filter(p => p.id !== id))
  }

  const filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase())
    const matchCat = !categoryFilter || p.category === categoryFilter
    return matchSearch && matchCat
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Ürün Yönetimi</h1>
          <p className="text-gray-500 text-sm mt-1">Menünüzdeki ürünleri yönetin, kategorilere ayırın</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all"><Plus size={16} /> Yeni Ürün</button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-xs"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" /><input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Ürün ara..." className="w-full bg-[#0d1117]/80 border border-[#1a2332] rounded-xl pl-9 pr-4 py-2 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" /></div>
        <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="bg-[#0d1117]/80 border border-[#1a2332] rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-emerald-500/50 transition-all"><option value="">Tüm Kategoriler</option>{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select>
        <button onClick={() => { setSearch(''); setCategoryFilter('') }} className="px-3 py-2 text-xs text-gray-500 hover:text-white transition-all">Temizle</button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map(p => (
          <div key={p.id} className="glass rounded-2xl border border-[#1a2332] overflow-hidden hover:border-emerald-500/20 transition-all group">
            <div className="aspect-[4/3] bg-[#080b12] flex items-center justify-center relative overflow-hidden">
              {p.image ? (
                <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              ) : (
                <div className="text-center"><ImageIcon size={36} className="text-gray-700 mx-auto mb-2" /><p className="text-xs text-gray-600">Görsel Yok</p></div>
              )}
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                <button onClick={() => openEdit(p)} className="p-1.5 rounded-lg bg-black/60 backdrop-blur-sm text-white hover:bg-emerald-500/60 transition-all"><Pencil size={13} /></button>
                <button onClick={() => remove(p.id)} className="p-1.5 rounded-lg bg-black/60 backdrop-blur-sm text-white hover:bg-red-500/60 transition-all"><Trash2 size={13} /></button>
              </div>
              {!p.active && <div className="absolute inset-0 bg-black/50 flex items-center justify-center"><span className="text-xs font-medium text-gray-400 bg-black/60 px-3 py-1 rounded-full">Pasif</span></div>}
            </div>
            <div className="p-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-white text-sm font-semibold leading-tight">{p.name}</h3>
                <span className="text-emerald-400 text-sm font-bold whitespace-nowrap">{p.price.toFixed(2)} ₺</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="flex items-center gap-1 px-2 py-0.5 bg-purple-500/5 text-purple-400 rounded-lg border border-purple-500/10"><Layers size={10} />{p.category}</span>
                <span className={'flex items-center gap-1 px-2 py-0.5 rounded-lg border ' + (p.stock > 50 ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10' : p.stock > 0 ? 'bg-amber-500/5 text-amber-400 border-amber-500/10' : 'bg-red-500/5 text-red-400 border-red-500/10')}><Tag size={10} />Stok: {p.stock}</span>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center py-20 text-gray-500">
            <Package size={48} className="mx-auto mb-3 text-gray-700" />
            <p className="text-sm">Ürün bulunamadı</p>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowModal(false)} />
          <div className="relative w-full max-w-lg bg-[#0d1117] border border-[#1a2332] rounded-2xl shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">{editing ? 'Ürün Düzenle' : 'Yeni Ürün'}</h3>
              <button onClick={() => setShowModal(false)} className="p-2 rounded-lg hover:bg-white/5 text-gray-500"><X size={18} /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 block mb-1.5">Ürün Adı</label>
                <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Ürün adı" className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 block mb-1.5">Kategori</label>
                  <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 transition-all">{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-1.5">Fiyat (₺)</label>
                  <div className="relative"><DollarSign size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" /><input type="number" step="0.01" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} placeholder="0.00" className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl pl-9 pr-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" /></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 block mb-1.5">Stok Miktarı</label>
                  <input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} placeholder="0" className="w-full bg-[#080b12]/80 border border-[#1a2332] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/50 placeholder-gray-600 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-1.5">Durum</label>
                  <div className="flex gap-2 h-full items-center pt-1">
                    <button onClick={() => setForm({ ...form, active: true })} className={'flex-1 py-2 rounded-xl text-xs font-medium border transition-all ' + (form.active ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-[#080b12]/50 border-[#1a2332] text-gray-500')}>Aktif</button>
                    <button onClick={() => setForm({ ...form, active: false })} className={'flex-1 py-2 rounded-xl text-xs font-medium border transition-all ' + (!form.active ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'bg-[#080b12]/50 border-[#1a2332] text-gray-500')}>Pasif</button>
                  </div>
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-500 block mb-1.5">Ürün Görseli</label>
                <div className="border-2 border-dashed border-[#1a2332] rounded-xl p-6 text-center hover:border-emerald-500/30 transition-all cursor-pointer">
                  <ImageIcon size={28} className="mx-auto mb-2 text-gray-600" />
                  <p className="text-xs text-gray-500">Görsel eklemek için tıklayın</p>
                  <p className="text-xs text-gray-600 mt-1">PNG, JPG, WEBP (API entegrasyonu gerektirir)</p>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowModal(false)} className="px-5 py-2.5 border border-[#1a2332] text-gray-400 rounded-xl text-sm font-medium hover:text-white transition-all">İptal</button>
              <button onClick={save} disabled={!form.name || !form.price} className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50">Kaydet</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
